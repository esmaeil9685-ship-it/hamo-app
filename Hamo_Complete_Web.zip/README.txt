HAMO — Complete Web Prototype
=============================

Contents:
- index.html: self-contained Persian RTL mobile-first web prototype.
- README.txt: these instructions.

How to publish with GitHub Pages:
1. Upload index.html to the root of the public repository named hamo-app.
2. Open repository Settings -> Pages.
3. Under Build and deployment, choose "Deploy from a branch".
4. Choose branch "main" and folder "/ (root)", then Save.
5. Wait a few minutes. The public site should be at:
   https://esmaeil9685-ship-it.github.io/hamo-app/

Important:
This is a prototype, not a production-ready all-in-one service. It includes broad marketplace categories and service shortcuts, a local demo ad form, search, and mobile layout. Demo ads are saved only in the same browser/device. Login, shared database, chat, moderation, payments, bookings, live maps, streaming, and official service integrations are not enabled. Do not place passwords, API secrets, or Supabase service-role keys in this public repository.
